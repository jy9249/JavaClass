package Omok;

import java.util.Scanner;

public class java000 {

	private static int wc;
	private static int wr;
	private static int br;
	private static int bc;

	public static void main(String[] args) {

		final int MAX = 19;
		int pan[][] = new int[MAX][MAX]; // 바둑판 2차원 배열
		int r = 0, c = 0, n = 0, wrow = 0, wcol = 0, brow = 0, bcol = 0;

		// 바둑판 빈공간 0으로 채우기
		for (int i = 0; i < MAX; i++) {
			for (int j = 0; j < MAX; j++) {
				pan[i][j] = 0;

			}
			System.out.println();

		}
		for (;;) {
			System.out.println();
			System.out.println("가로를 입력하시오");
			Scanner sc = new Scanner(System.in);
			r = sc.nextInt();
			System.out.println("세로를 입력하시오");
			Scanner sc1 = new Scanner(System.in);
			c = sc1.nextInt();
			System.out.printf("[%d,%d]자리에 바둑돌을 놓으시겠습니까? 놓으려면 '1' 입력", r, c);
			Scanner sc2 = new Scanner(System.in);
			int cnt = sc2.nextInt();
			pan[r][c] = cnt;
			/*
			 * if (pan[r][c] == 1 || pan[r][c] == 2) {
			 * System.out.println("이 자리에 놓을 수 없습니다."); }
			 */
			int min = -1;
			int max = 1;
			System.out.printf("[%d,%d]에 돌을 두셨습니다.", r, c);
			n = (int) (Math.random() * (max - min + 1)) + min;

			if (n == 0) {

				while (n == 0) {
					n = (int) (Math.random() * (max - min + 1)) + min;
					if (n != 0) {
						pan[r - n][c + n] = 2;
						System.out.println();
						System.out.printf("컴퓨터가 [%d,%d]에 놨습니다.", r - n, c + n);
						System.out.println();
						break;
					}
				}

			} else {
				pan[r - n][c + n] = 2;
				System.out.println();
				System.out.printf("컴퓨터가 [%d,%d]에 놨습니다.", r - n, c + n);
				System.out.println();

			}

			for (int i = 0; i < MAX; i++) {
				wr = 0;
				wc = 0;
				br = 0;
				bc = 0;

				for (int j = 0; j < MAX; j++) {
					if (pan[i][j] == 1) // 내가 좋은 바둑알
					{
						if (wc == 5) // 흰 바둑알 가로로 5 개 연속
						{
							System.out.printf("세로로 [%d,%d]위치 에서 컴퓨터가 승리했습니다.", i + 1, j - 4);

							OmokMe(MAX, pan);

							OmokCom(MAX, pan);

							return;
						}
						wc = 0; // 연속 끊김
						bc++;// 검정바둑돌 col
					}

					else if (pan[i][j] == 2) // 커 바둑알
					{
						if (bc == 5) // 검은 바둑알 가로로 5개
						{
							System.out.printf("가로로 [%d,%d]위치 에서 내가 승리했습니다.", i, j - 5);

							OmokMe(MAX, pan);

							OmokCom(MAX, pan);
							return;
						}
						wc++; // 흰색바둑알연속
						bc = 0; // 끊겼으니 초기화
					} else { // 비어있는경우
						if (wc == 5)// 흰 바둑알이 가로로 5개
						{
							System.out.printf("[%d,%d]위치 에서 컴퓨터가 승리했습니다.", i, j - 5);
							OmokMe(MAX, pan);

							OmokCom(MAX, pan);
							return;
						}
						if (bc == 5) // 검은 바둑알이 가로로 5개
						{
							System.out.printf("가로로 [%d,%d]위치 에서 내가 승리했습니다.", i, j - 5);

							OmokMe(MAX, pan);

							OmokCom(MAX, pan);

							return;

						}
						wc = 0; // 초기화
						bc = 0; // 초기화
					}

					/* 세로 줄 검사 */
					if (pan[j][i] == 1)// 검정바둑알
					{
						if (wr == 5) // 흰 바둑알 5 개 연속
						{
							System.out.printf("[%d,%d]위치 에서 컴퓨터가 승리했습니다.", i, j - 5);
							OmokMe(MAX, pan);

							OmokCom(MAX, pan);
							return;
						}
						wr = 0;
						br++;
					}

					else if (pan[j][i] == 2) // 흰 바둑알
					{
						if (br == 5) // 검은 바둑알 5개
						{
							System.out.printf("세로로 [%d,%d]위치 에서 내가 승리했습니다.", j - 4, i + 1);

							OmokMe(MAX, pan);

							OmokCom(MAX, pan);

							return;
						}
					} else {
						if (wr == 5)// 흰 바둑알이 가로로 5개
						{
							System.out.printf("[%d,%d]위치 에서 컴퓨터가 승리했습니다.", i, j - 5);

							OmokMe(MAX, pan);

							OmokCom(MAX, pan);
							return;
						}
						if (br == 5) // 검은 바둑알이 가로로 5개
						{
							System.out.printf("새로로 [%d,%d]위치 에서 내가 승리했습니다.", i, j - 5);

							OmokMe(MAX, pan);

							OmokCom(MAX, pan);
							return;

						}
						wr = 0;
						br = 0;
					}
				}

			}

			if (br == 5 || bc == 5 || wc == 5 || wr == 5) {
				for (int i = 0; i < MAX; i++) {
					for (int j = 0; j < MAX; j++) {

						System.out.print(pan[i][j]);
					}
					System.out.println();

				}

				break;
			}

		}

	}

	private static void OmokMe(final int MAX, int[][] pan) {
		int i = 0;
		int j = 0;
		for (i = 0; i < MAX; i++) {
			for (j = 0; j < MAX; j++) {
				if (pan[i][j] == 1) {

					System.out.println();
					System.out.printf("내가가 놓은 돌은 [%d,%d]", i, j);
				}
			}
		}
	}

	private static void OmokCom(final int MAX, int[][] pan) {
		int i = 0;
		int j = 0;
		for (i = 0; i < MAX; i++) {
			for (j = 0; j < MAX; j++) {
				if (pan[i][j] == 2) {

					System.out.println();
					System.out.printf("컴퓨터가 놓은 돌은 [%d,%d]", i, j);
				}
			}
		}
	}

}
